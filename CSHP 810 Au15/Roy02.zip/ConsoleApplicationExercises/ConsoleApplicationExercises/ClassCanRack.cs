﻿/*
 * Name: Lorne Roy
 * Student ID: 0034514 
 */

using System;
using System.Diagnostics;

namespace ConsoleApplicationExercises
{

    /// <summary>
    /// This class will represent a can storage rack of the vending machine. 
    /// A can of soda will simply be represented as a number(e.g., orangeCans = 1 means there is one can of orange soda in the rack).
    /// </summary>
    class CanRack
    {
        #region constants
        #endregion

        #region fields

        private CanBin[] _canShelves;
        #endregion

        #region properties


        #endregion

        #region constructors
        // Constructor for a can rack. The rack starts out full
        public CanRack() 
        {
            _canShelves = new CanBin[3];
            //create three shelves for the three flavors of soda
            // Regular, Orange, and Lemon
            _canShelves[0] = new CanBin();
            _canShelves[0].Flavor = "regular";
            _canShelves[1] = new CanBin();
            _canShelves[1].Flavor = "lemon";
            _canShelves[2] = new CanBin();
            _canShelves[2].Flavor = "orange";
        }

        #endregion

        #region methods

        /// <summary>
        /// this method finds the array index of the can bin from the flavor
        /// </summary>
        /// <param name="flavor">the flavor associated with the bin</param>
        /// <returns>the array index of the bin in the array</returns>
        private int FlavorIndex(string flavor)
        {
            Debug.WriteLine("Flavor index method called");
            
            int _index = -1;
            
            //foreach (CanBin bin in _canShelves
            for (int i = 0; i < _canShelves.Length; i++)
            {
                if (_canShelves[i].Flavor == flavor)
                {
                    _index = i;
                    break;
                }
            }

            Debug.WriteLine("The flavor index is " + _index);

            if (_index == -1)
            {
                throw new Exception("flavor not found");
            }

            return _index;
        }

        // This method adds a can of the specified flavor to the rack.
        public void AddACanOf(string FlavorOfCanToBeAdded) 
        {
            Debug.WriteLine("AddACanOf method called");
            _canShelves[FlavorIndex(FlavorOfCanToBeAdded)].AddACan();
        }

        // This method will remove a can of the specified flavor from the rack.
        public void RemoveACanOf(string FlavorOfCanToBeRemoved) 
        {
            Debug.WriteLine("RemoveACanOf method called");
            _canShelves[FlavorIndex(FlavorOfCanToBeRemoved)].RemoveACan();
        }
        
        // This method will fill the can rack.
        public void FillTheCanRack() 
        {
            Debug.WriteLine("FillTheCanRack method called");
            foreach (CanBin bin in _canShelves)
            {
                bin.FillTheCanBin();
            }
 
        }
        
        // This public void will empty the rack of a given flavor.
        public void EmptyCanRackOf(string FlavorOfBinToBeEmptied) 
        {
            Debug.WriteLine("EmptyCanRackOf method called");
            foreach (CanBin bin in _canShelves)
            {
                bin.EmptyCanBin();
            }
        }
        // OPTIONAL – returns true if the rack is full of a specified flavor
        // false otherwise
        public Boolean IsFull(string FlavorOfBinToCheck)
        {
            Debug.WriteLine("IsFull method called");
            return _canShelves[FlavorIndex(FlavorOfBinToCheck)].IsFull();
        }
        // OPTIONAL – return true if the rack is empty of a specified flavor
        // false otherwise
        public Boolean IsEmpty(string FlavorOfBinToCheck)
        {
            Debug.WriteLine("IsEmpty method called");
            return _canShelves[FlavorIndex(FlavorOfBinToCheck)].IsEmpty();
        }


        #endregion

    } //end Can_Rack

    /// <summary>
    /// A can bin contains a single flavor within a CanRack
    /// </summary>
    internal class CanBin
    {
        #region constants
        public static int maxCans = 10;

        #endregion

        #region fields
        private int _cans;
        private string _flavor;


        #endregion

        #region properties
        public int Cans
        {
            get { return _cans; }
            private set { _cans = value; }
        }

        public string Flavor
        {
            get { return _flavor; }
            set { _flavor = value; }
        }

        #endregion

        #region constructors

        public CanBin(string flavor)
        {
            Flavor = flavor;
            FillTheCanBin();
        }

        public CanBin() 
        {
            FillTheCanBin();
        }
        #endregion

        #region methods
        // This method adds a can of the specified flavor to the rack.
        public void AddACan()
        {
            if (!IsFull())
            {
                Cans += 1;
            }
            else
            {
                throw new Exception("Shelf is full");
            }
        }

        // This method will remove a can of the specified flavor from the rack.
        public void RemoveACan()
        {
            if (!IsEmpty())
            {
                Cans -= 1;
            }
            else
            {
                throw new Exception("Shelf is empty");
            }
        }

        // This method will fill the can bin.
        public void FillTheCanBin() 
        {
            Cans = maxCans;
        }

        // This public void will empty the bin.
        public void EmptyCanBin() 
        {
            Cans = 0;
        }


        /// <summary>
        /// this method returns true if the bin is full
        /// </summary>
        /// <returns>true if the bin is full</returns>
        public Boolean IsFull()
        {
            if (Cans == maxCans)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// this method returns true if the bin is empty
        /// </summary>
        /// <returns>true if the bin is empty</returns>
        public Boolean IsEmpty() 
        {
            if (Cans == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        #endregion
    }
}
