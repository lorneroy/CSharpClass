﻿/*
 * Name: Lorne Roy
 * Student ID: 0034514 
 */

using System;


namespace ConsoleApplicationExercises
{
    class Program
    {
        static void Main(string[] args)
        {
            CanRack canRack = new CanRack();//this is the rack of cans in the machine with bins of original, lemon, and orange

            PurchasePrice sodaPrice = new PurchasePrice(35); //the price of the product in US cents

            string input;//input string from user
            short inputNumber;//numeric representation of the input

            Console.WriteLine("Welcome to the .NET C# Soda Vending Machine");
            while (true)
            {

                Console.Write("Please insert {0} cents:", sodaPrice.Price);
                input = Console.ReadLine();

                if (Int16.TryParse(input, out inputNumber))
                {
                    Console.WriteLine("You have inserted {0} cents", inputNumber);
                    if (inputNumber >= sodaPrice.Price)
                    {
                        Console.WriteLine("What flavor would you like:");
                        foreach (string flavor in Enum.GetNames(typeof(Flavor)))
                        {
                            Console.WriteLine(flavor);
                        }
                        string flavorEntry = Console.ReadLine();
                        try 
	                    {
                            canRack.RemoveACanOf(flavorEntry);
                            Console.WriteLine("Thanks. Here is your soda.");
                            Console.WriteLine("Returning {0} cents", inputNumber - sodaPrice.Price);
	                    }
	                    catch (Exception)
	                    {
                            Console.WriteLine("Something is wrong");
                            Console.WriteLine("Returning {0} cents", inputNumber);
	                    }
                    }
                    else
                    {
                        Console.WriteLine("That is not enough money");
                        Console.WriteLine("Returning {0} cents", inputNumber);
                    }
                }
                else
                {
                    Console.WriteLine("That is not a form of currency.  Goodbye.");
                    break;
                }
            }
        }

    }
}
