﻿using System;
using System.Collections.Generic;

namespace ConsoleApplicationExercises
{
    public static class FlavorOps
    {
        #region constants
        
        #endregion

        #region fields
        private static List<Flavor> _allFlavors = new List<Flavor>((Flavor[])Enum.GetValues(typeof(Flavor)));
        
        #endregion

        #region properties
        public static List<Flavor> AllFlavors
        {
            // property to return a List<Flavor> of all of the Varieties
            get 
            {
                return _allFlavors;
            }
        }
        #endregion

        #region constructors
        static FlavorOps() { }

        #endregion


        #region methods

        // method to convert a string value into an enumeral
        public static Flavor ToFlavor(string FlavorName)
        {
            //Enum.GetNames(typeof(Flavor))
            return (Flavor) Enum.Parse(typeof(Flavor), FlavorName);
        }
        #endregion

    }
}
