﻿/*
 * Name: Lorne Roy
 * Student ID: 0034514 
 */

using System;


namespace ConsoleApplicationExercises
{
    class Program
    {
        static void Main(string[] args)
        {
            CanRack canRack = new CanRack();//this is the rack of cans in the machine with bins of original, lemon, and orange
   
            bool quit = false;//flag used for quitting the application from a user input
            
            PurchasePrice sodaPrice = new PurchasePrice(35); //the price of the product in US cents

            string input;//input string from user

            decimal insertedMoney; //total money inserted

            Console.WriteLine("Welcome to the .NET C# Soda Vending Machine");
            while (true)
            {
                insertedMoney = 0;
                canRack.DisplayCanRack();

                Console.WriteLine("Please insert {0} cents (or X to exit):", sodaPrice.Price);
                while (true)
                {
                    Console.Write("Please insert a coin:");
                    input = Console.ReadLine().ToUpper();
                    if (input.ToUpper() == "X")
                    {
                        quit = true;
                        break;
                    }
                    else
                    {

                        try
                        {
                            Coin insertedCoin = new Coin(input);
                            insertedMoney += insertedCoin.ValueOf;
                            Console.WriteLine("You have inserted {0} cents total", (int)(insertedMoney * 100));
                            if (insertedMoney >= sodaPrice.PriceDecimal)
                            {
                                Console.WriteLine("Thank you");
                                break;
                            }
                        }
                        catch (Exception)
                        {
                            Console.WriteLine("That is not a form of currency.");
                        }

                    }
                }
                if (quit)
                {
                    break;
                }
                Console.WriteLine("What flavor would you like:");
                foreach (string flavor in Enum.GetNames(typeof(Flavor)))
                {
                    Console.WriteLine(flavor);
                }
                string flavorEntry = Console.ReadLine();
                try
                {
                    canRack.RemoveACanOf(flavorEntry);
                    Console.WriteLine("Thanks. Here is your soda.");
                    Console.WriteLine("Returning {0} cents", (int)((insertedMoney - sodaPrice.PriceDecimal) * 100));
                }
                catch (Exception e)
                {
                    Console.WriteLine("Something is wrong");
                    Console.WriteLine(e.Message);
                    Console.WriteLine("Returning {0} cents", (int)((insertedMoney) * 100));

                }
            }
        }
    }
}
