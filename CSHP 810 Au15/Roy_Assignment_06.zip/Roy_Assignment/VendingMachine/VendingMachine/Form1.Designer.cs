﻿namespace VendingMachine
{
    partial class VendingMachine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VendingMachine));
            this.labelGeneralMessage = new System.Windows.Forms.Label();
            this.labelExactChange = new System.Windows.Forms.Label();
            this.labelCredit = new System.Windows.Forms.Label();
            this.pictureBoxOrange = new System.Windows.Forms.PictureBox();
            this.pictureBoxLemon = new System.Windows.Forms.PictureBox();
            this.pictureBoxRegular = new System.Windows.Forms.PictureBox();
            this.buttonReturn = new System.Windows.Forms.Button();
            this.buttonOrange = new System.Windows.Forms.Button();
            this.buttonLemon = new System.Windows.Forms.Button();
            this.buttonRegular = new System.Windows.Forms.Button();
            this.buttonHalfDollar = new System.Windows.Forms.Button();
            this.buttonQuarter = new System.Windows.Forms.Button();
            this.buttonDime = new System.Windows.Forms.Button();
            this.buttonNickel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOrange)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLemon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRegular)).BeginInit();
            this.SuspendLayout();
            // 
            // labelGeneralMessage
            // 
            this.labelGeneralMessage.AutoSize = true;
            this.labelGeneralMessage.Location = new System.Drawing.Point(13, 13);
            this.labelGeneralMessage.Name = "labelGeneralMessage";
            this.labelGeneralMessage.Size = new System.Drawing.Size(35, 13);
            this.labelGeneralMessage.TabIndex = 0;
            this.labelGeneralMessage.Text = "label1";
            // 
            // labelExactChange
            // 
            this.labelExactChange.AutoSize = true;
            this.labelExactChange.Location = new System.Drawing.Point(13, 30);
            this.labelExactChange.Name = "labelExactChange";
            this.labelExactChange.Size = new System.Drawing.Size(35, 13);
            this.labelExactChange.TabIndex = 1;
            this.labelExactChange.Text = "label2";
            // 
            // labelCredit
            // 
            this.labelCredit.AutoSize = true;
            this.labelCredit.Location = new System.Drawing.Point(13, 47);
            this.labelCredit.Name = "labelCredit";
            this.labelCredit.Size = new System.Drawing.Size(35, 13);
            this.labelCredit.TabIndex = 2;
            this.labelCredit.Text = "label3";
            // 
            // pictureBoxOrange
            // 
            this.pictureBoxOrange.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxOrange.Image")));
            this.pictureBoxOrange.Location = new System.Drawing.Point(218, 11);
            this.pictureBoxOrange.Name = "pictureBoxOrange";
            this.pictureBoxOrange.Size = new System.Drawing.Size(100, 100);
            this.pictureBoxOrange.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxOrange.TabIndex = 3;
            this.pictureBoxOrange.TabStop = false;
            // 
            // pictureBoxLemon
            // 
            this.pictureBoxLemon.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLemon.Image")));
            this.pictureBoxLemon.Location = new System.Drawing.Point(218, 117);
            this.pictureBoxLemon.Name = "pictureBoxLemon";
            this.pictureBoxLemon.Size = new System.Drawing.Size(100, 100);
            this.pictureBoxLemon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxLemon.TabIndex = 4;
            this.pictureBoxLemon.TabStop = false;
            // 
            // pictureBoxRegular
            // 
            this.pictureBoxRegular.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxRegular.Image")));
            this.pictureBoxRegular.Location = new System.Drawing.Point(218, 221);
            this.pictureBoxRegular.Name = "pictureBoxRegular";
            this.pictureBoxRegular.Size = new System.Drawing.Size(100, 100);
            this.pictureBoxRegular.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxRegular.TabIndex = 5;
            this.pictureBoxRegular.TabStop = false;
            // 
            // buttonReturn
            // 
            this.buttonReturn.Location = new System.Drawing.Point(12, 298);
            this.buttonReturn.Name = "buttonReturn";
            this.buttonReturn.Size = new System.Drawing.Size(75, 23);
            this.buttonReturn.TabIndex = 6;
            this.buttonReturn.Text = "Return";
            this.buttonReturn.UseVisualStyleBackColor = true;
            this.buttonReturn.Click += new System.EventHandler(this.buttonReturn_Click);
            // 
            // buttonOrange
            // 
            this.buttonOrange.Location = new System.Drawing.Point(336, 47);
            this.buttonOrange.Name = "buttonOrange";
            this.buttonOrange.Size = new System.Drawing.Size(75, 23);
            this.buttonOrange.TabIndex = 7;
            this.buttonOrange.Text = "Orange";
            this.buttonOrange.UseVisualStyleBackColor = true;
            this.buttonOrange.Click += new System.EventHandler(this.buttonOrange_Click);
            // 
            // buttonLemon
            // 
            this.buttonLemon.Location = new System.Drawing.Point(336, 157);
            this.buttonLemon.Name = "buttonLemon";
            this.buttonLemon.Size = new System.Drawing.Size(75, 23);
            this.buttonLemon.TabIndex = 8;
            this.buttonLemon.Text = "Lemon";
            this.buttonLemon.UseVisualStyleBackColor = true;
            this.buttonLemon.Click += new System.EventHandler(this.buttonLemon_Click);
            // 
            // buttonRegular
            // 
            this.buttonRegular.Location = new System.Drawing.Point(336, 251);
            this.buttonRegular.Name = "buttonRegular";
            this.buttonRegular.Size = new System.Drawing.Size(75, 23);
            this.buttonRegular.TabIndex = 9;
            this.buttonRegular.Text = "Regular";
            this.buttonRegular.UseVisualStyleBackColor = true;
            this.buttonRegular.Click += new System.EventHandler(this.buttonRegular_Click);
            // 
            // buttonHalfDollar
            // 
            this.buttonHalfDollar.Location = new System.Drawing.Point(16, 161);
            this.buttonHalfDollar.Name = "buttonHalfDollar";
            this.buttonHalfDollar.Size = new System.Drawing.Size(75, 23);
            this.buttonHalfDollar.TabIndex = 10;
            this.buttonHalfDollar.Text = "Half Dollar";
            this.buttonHalfDollar.UseVisualStyleBackColor = true;
            this.buttonHalfDollar.Click += new System.EventHandler(this.buttonHalfDollar_Click);
            // 
            // buttonQuarter
            // 
            this.buttonQuarter.Location = new System.Drawing.Point(16, 191);
            this.buttonQuarter.Name = "buttonQuarter";
            this.buttonQuarter.Size = new System.Drawing.Size(75, 23);
            this.buttonQuarter.TabIndex = 11;
            this.buttonQuarter.Text = "Quarter";
            this.buttonQuarter.UseVisualStyleBackColor = true;
            this.buttonQuarter.Click += new System.EventHandler(this.buttonQuarter_Click);
            // 
            // buttonDime
            // 
            this.buttonDime.Location = new System.Drawing.Point(16, 221);
            this.buttonDime.Name = "buttonDime";
            this.buttonDime.Size = new System.Drawing.Size(75, 23);
            this.buttonDime.TabIndex = 12;
            this.buttonDime.Text = "Dime";
            this.buttonDime.UseVisualStyleBackColor = true;
            this.buttonDime.Click += new System.EventHandler(this.buttonDime_Click);
            // 
            // buttonNickel
            // 
            this.buttonNickel.Location = new System.Drawing.Point(16, 251);
            this.buttonNickel.Name = "buttonNickel";
            this.buttonNickel.Size = new System.Drawing.Size(75, 23);
            this.buttonNickel.TabIndex = 13;
            this.buttonNickel.Text = "Nickel";
            this.buttonNickel.UseVisualStyleBackColor = true;
            this.buttonNickel.Click += new System.EventHandler(this.buttonNickel_Click);
            // 
            // VendingMachine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(465, 392);
            this.Controls.Add(this.buttonNickel);
            this.Controls.Add(this.buttonDime);
            this.Controls.Add(this.buttonQuarter);
            this.Controls.Add(this.buttonHalfDollar);
            this.Controls.Add(this.buttonRegular);
            this.Controls.Add(this.buttonLemon);
            this.Controls.Add(this.buttonOrange);
            this.Controls.Add(this.buttonReturn);
            this.Controls.Add(this.pictureBoxRegular);
            this.Controls.Add(this.pictureBoxLemon);
            this.Controls.Add(this.pictureBoxOrange);
            this.Controls.Add(this.labelCredit);
            this.Controls.Add(this.labelExactChange);
            this.Controls.Add(this.labelGeneralMessage);
            this.Name = "VendingMachine";
            this.Text = "Vending Machine";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOrange)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLemon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRegular)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelGeneralMessage;
        private System.Windows.Forms.Label labelExactChange;
        private System.Windows.Forms.Label labelCredit;
        private System.Windows.Forms.PictureBox pictureBoxOrange;
        private System.Windows.Forms.PictureBox pictureBoxLemon;
        private System.Windows.Forms.PictureBox pictureBoxRegular;
        private System.Windows.Forms.Button buttonReturn;
        private System.Windows.Forms.Button buttonOrange;
        private System.Windows.Forms.Button buttonLemon;
        private System.Windows.Forms.Button buttonRegular;
        private System.Windows.Forms.Button buttonHalfDollar;
        private System.Windows.Forms.Button buttonQuarter;
        private System.Windows.Forms.Button buttonDime;
        private System.Windows.Forms.Button buttonNickel;
    }
}

