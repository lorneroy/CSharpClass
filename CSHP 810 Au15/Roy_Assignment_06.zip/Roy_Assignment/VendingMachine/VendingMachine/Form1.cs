﻿/*
 * Lorne Roy
 * Student ID 0034514
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _06._0_Console_As_Library;

namespace VendingMachine
{
    public partial class VendingMachine : Form
    {
        #region constants
        #endregion

        #region private fields
        private CoinBox _coinBoxTransaction;
        private CoinBox _coinBoxLocked;
        private PurchasePrice _sodaPrice;
        private CanRack _canRack;
        #endregion

        #region properties
        #endregion

        #region contructor

        public VendingMachine()
        {
            
            InitializeComponent();
            _canRack = new CanRack();
            _canRack.FillTheCanRack();
           
            _coinBoxTransaction = new CoinBox();
            _sodaPrice = new PurchasePrice(35);
            labelCredit.Text = String.Format("{0:c}", _coinBoxTransaction.ValueOf);
            labelExactChange.Text = "Exact Change Required";
            labelExactChange.Visible = false;
            labelGeneralMessage.Text = "Welcome";
            buttonLemon.Enabled = false;
            buttonOrange.Enabled = false;
            buttonRegular.Enabled = false;


            _coinBoxLocked = new CoinBox();
            foreach (Coin.Denomination cn in Coin.AllDenominations)
            {
                for (int i = 0; i < 2; i++)
                {
                    _coinBoxLocked.Deposit(new Coin(cn));
                }
            }
        }
        
        #endregion

        #region methods
        private void enoughMoney()
        {
            labelCredit.Text = String.Format("{0:c}", _coinBoxTransaction.ValueOf);

            if (_coinBoxTransaction.ValueOf >= _sodaPrice.PriceDecimal)
            {
                if (_coinBoxLocked.CanMakeChange || (_coinBoxTransaction.ValueOf == _sodaPrice.PriceDecimal))
                {
                    labelExactChange.Visible = false;
                    buttonOrange.Enabled = true;
                    buttonLemon.Enabled = true;
                    buttonRegular.Enabled = true;
                }
                else
                {
                    labelExactChange.Visible = true;
                    buttonOrange.Enabled = false;
                    buttonLemon.Enabled = false;
                    buttonRegular.Enabled = false;
                }
            }
            else
            {
                buttonOrange.Enabled = false;
                buttonLemon.Enabled = false;
                buttonRegular.Enabled = false;
            }
        }

        private void makeChange()
        {
            decimal credit;
            credit = _coinBoxTransaction.ValueOf - _sodaPrice.PriceDecimal;
            _coinBoxTransaction.Transfer(_coinBoxLocked);
            _coinBoxLocked.Transfer(_coinBoxTransaction, credit, true);

        }

        private void checkFlavors()
        {
            if (_canRack.IsEmpty(Flavor.LEMON))
            {
                buttonLemon.Enabled = false;
            }
            if (_canRack.IsEmpty(Flavor.ORANGE))
            {
                buttonOrange.Enabled = false;
            }
            if (_canRack.IsEmpty(Flavor.REGULAR))
            {
                buttonRegular.Enabled = false;
            }

        }

        private void buttonHalfDollar_Click(object sender, EventArgs e)
        {
            _coinBoxTransaction.Deposit(Coin.HALFDOLLARCOIN);
            enoughMoney();
            checkFlavors();
        }

        private void buttonQuarter_Click(object sender, EventArgs e)
        {
            _coinBoxTransaction.Deposit(Coin.QUARTERCOIN);
            enoughMoney();
            checkFlavors();
        }

        private void buttonDime_Click(object sender, EventArgs e)
        {
            _coinBoxTransaction.Deposit(Coin.DIMECOIN);
            enoughMoney();
            checkFlavors();
        }

        private void buttonNickel_Click(object sender, EventArgs e)
        {
            _coinBoxTransaction.Deposit(Coin.NICKELCOIN);
            enoughMoney();
            checkFlavors();
        }

        private void buttonReturn_Click(object sender, EventArgs e)
        {
            _coinBoxTransaction.Withdraw(_coinBoxTransaction.ValueOf);
            enoughMoney();
        }
        
        private void buttonOrange_Click(object sender, EventArgs e)
        {
            _canRack.RemoveACanOf(Flavor.ORANGE);
            makeChange();
            enoughMoney();
            checkFlavors();
        }

        private void buttonLemon_Click(object sender, EventArgs e)
        {
            _canRack.RemoveACanOf(Flavor.LEMON);
            makeChange();
            enoughMoney();
            checkFlavors();
        }

        private void buttonRegular_Click(object sender, EventArgs e)
        {
            _canRack.RemoveACanOf(Flavor.REGULAR);
            makeChange();
            enoughMoney();
            checkFlavors();

        }


        #endregion


    }
}
