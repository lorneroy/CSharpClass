﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestHarness
{
    class Program
    {
        static void Main(string[] args)
        {
            DataAccessLayer.Employee objE = new DataAccessLayer.Employee();
            int NewID, RC;
            RC = objE.InsEmployee("test", out NewID);
            Console.WriteLine("RC: {0} and NewID: {1}", RC, NewID);
            Console.ReadLine();
        }
    }
}
