﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data;
using System.Data.Entity.Core.Objects;

namespace DataAccessLayer
{
    public class Employee : IEmployeeRepository
    {
        IEnumerable<Employee> objEmployees;
        int objEmployeeID;
        string objEmployeeName;

        public IEnumerable<Employee> Employees
        {
            get
            {
                return objEmployees;
            }
            set
            {
              objEmployees = value ;
            }
        }

        public int EmployeeID
        {
            get
            {
                return objEmployeeID;
            }
            set
            {
              objEmployeeID = value ;
            }
        }

        public string EmployeeName
        {
            get
            {
                return objEmployeeName;
            }
            set
            {
              objEmployeeName = value ;
            }
        }

        public int InsEmployee(string EmployeeName, out int NewRowID)
        {
            //return ADONetOption(EmployeeName, out NewRowID);
            return EFOption(EmployeeName, out NewRowID);
        }

        private static int ADONetOption(string EmployeeName, out int NewRowID)
        {
            //Set up the variables
            int intRC = 0; //Used to trap the Stored Procedure's return code

            //Create a Connection object using my custom connection factory
            System.Data.SqlClient.SqlConnection objCon = new ADOConnectionFactory().Connection;

            //Set up the parameters using my custom parameter factory
            IParameterFactory objParams = new EmployeesParameterFactory(EmployeeName: EmployeeName);  
          
            //Create and configure an ADO.NET command object 
            System.Data.SqlClient.SqlCommand objCmd = new SqlCommand("", objCon);
            objCmd.Parameters.Add(objParams.Parmeters["RC"]);
            objCmd.Parameters.Add(objParams.Parmeters["EmployeeName"]);
            objCmd.Parameters.Add(objParams.Parmeters["NewRowID"]);
            objCmd.CommandType = CommandType.StoredProcedure;
            objCmd.CommandText = "pInsEmployees";

            try
            {
                objCmd.Connection.Open();
                objCmd.ExecuteNonQuery();

                //Get the new row ID created by the table's Identity feature
                if (objParams.Parmeters["NewRowID"].Value is DBNull)
                { NewRowID = 0; } //if the insert has failed, then set this to an arbitrary number
                else { NewRowID = (int)objParams.Parmeters["NewRowID"].Value; } //else send it back as output

                //Trap or return the Stored Procedure's return code
                intRC = (int)objParams.Parmeters["RC"].Value;
                if (intRC < 0)
                { throw new Exception("Error reported in Stored Procedure: " + objParams.Parmeters["RC"].Value.ToString()); }

                objCmd.Connection.Close();
            }
            catch (Exception) { throw; }
            return intRC;
        }

        private static int EFOption(string EmployeeName, out int NewRowID)
        {

            //Set up the variables
            int intRC = 0; //Used to trap the Stored Procedure's return code

            //Create a Connection object using Entity Framework (EF)
            IObjectContextAdapter Context = new EFDbContext();

            //Set up the parameters using my custom parameter factory
            IParameterFactory objParams = new EmployeesParameterFactory(EmployeeName: EmployeeName);
            //-- Change the RC parameter from ReturnValue to Output, since the EF does not support ReturnValue (Crazy!)
            objParams.Parmeters["RC"].Direction = ParameterDirection.Output; 

            //Create and configure an ADO.NET command object 
            //-- Create a SQL command string
            string strSQLCode = @"Exec @RC = pInsEmployees" +
                                " @EmployeeName = '" + objParams.Parmeters["EmployeeName"] + "'" + // Don't forget the SINGLE Quotes!!!
                                ",@NewRowID = @NewRowID out;";
            //configure the command object and execute it
            try
            {
                Context.ObjectContext.ExecuteStoreCommand(strSQLCode
                                                            , objParams.Parmeters["RC"]
                                                            , objParams.Parmeters["EmployeeName"]
                                                            , objParams.Parmeters["NewRowID"]
                                                            );

                //Get the new row ID created by the table's Identity feature
                if (objParams.Parmeters["NewRowID"].Value is DBNull)
                { NewRowID = 0; } //if the insert has failed, then set this to an arbitrary number
                else { NewRowID = (int)objParams.Parmeters["NewRowID"].Value; } //else send it back as output

                //Trap or return the Stored Procedure's return code
                intRC = (int)objParams.Parmeters["RC"].Value;
                if (intRC < 0)
                { throw new Exception("Error reported in Stored Procedure: " + objParams.Parmeters["RC"].Value.ToString()); }
            }
            catch (Exception)
            {

                throw;
            }

            return intRC;
        }

        public int UpdEmployee(int EmployeeID, string EmployeeName)
        {
            throw new NotImplementedException();
        }

        public int DelEmployee(int EmployeeID)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Employee> SelEmployee()
        {
            throw new NotImplementedException();
        }
    }

    public class Project: IProjectRepository
    {

        public IEnumerable<Project> Projects
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public int ProjectID
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string ProjectName
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string ProjectDescription
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public int InsProject(string ProjectName, int ProjectDescription, out int NewRowID)
        {
            throw new NotImplementedException();
        }

        public int UpdProject(int ProjectID, string ProjectName, int ProjectDescription)
        {
            throw new NotImplementedException();
        }

        public int DelProject(int ProjectID)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Project> SelProjects()
        {
            throw new NotImplementedException();
        }
    }

    public class EmployeeProjectHour: IEmployeeProjectHourRepository
    {

        public IEnumerable<EmployeeProjectHour> EmployeeProjectHours
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public int EmployeeID
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public DateTime Date
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public int ProjectID
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public decimal Hours
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string EmployeeName
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string ProjectName
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public int InsEmployeeProjectHours(int EmployeeID, int ProjectID, DateTime Date, decimal Hours)
        {
            throw new NotImplementedException();
        }

        public int UpdEmployeeProjectHours(int EmployeeID, int ProjectID, DateTime Date, decimal Hours)
        {
            throw new NotImplementedException();
        }

        public int DelEmployeeProjectHours(int EmployeeID, int ProjectID, DateTime Date)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<EmployeeProjectHour> SelEmployeeProjectHours()
        {
            throw new NotImplementedException();
        }
    }

    public class ThisYearsDate: IThisYearsDateRepository
    {

        public IEnumerable<ThisYearsDate> ThisYearsDates
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public int DateID
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string DateName
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public IEnumerable<ThisYearsDate> SelThisYearsDates()
        {
            throw new NotImplementedException();
        }
    }

    public class ValidHourEntry : IValidHourEntryRepository
    {
        public IEnumerable<ValidHourEntry> ValidHourEntries
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public int TimePeriodID
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string TimePeriod
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public IEnumerable<ValidHourEntry> SelValidHourEntries()
        {
            throw new NotImplementedException();
        }
    }
}
