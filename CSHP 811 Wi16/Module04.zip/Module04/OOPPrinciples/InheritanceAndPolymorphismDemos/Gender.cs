﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InheritanceAndPolymorphismDemos
{
    public enum Gender
    {
        Male = 0,
        Female = 1,
    }
}
