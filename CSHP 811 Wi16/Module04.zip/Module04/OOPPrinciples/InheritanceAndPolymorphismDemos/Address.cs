﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InheritanceAndPolymorphismDemos
{
    public class Address
    {
        public string StreetAddress
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public string City
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public String State
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public string Country
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
