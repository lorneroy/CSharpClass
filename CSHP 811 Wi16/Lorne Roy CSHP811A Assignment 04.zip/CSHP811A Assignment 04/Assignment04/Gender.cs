﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment04
{
    public enum Gender
    {
        Male = 0,
        Female = 1,
    }
}
