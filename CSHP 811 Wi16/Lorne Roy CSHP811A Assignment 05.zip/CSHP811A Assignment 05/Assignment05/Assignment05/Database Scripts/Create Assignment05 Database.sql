USE [master]
GO

/****** Object:  Database [Assignment05]    Script Date: 2/25/2016 3:12:05 PM ******/
CREATE DATABASE [Assignment05]
GO
