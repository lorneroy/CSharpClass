﻿Use TempDB
Create Table Customers (ID int Primary Key, Name nVarChar(50));
Insert into Customers Values (1,'Bob'), (2,'Sue'),(3,'Tim');
